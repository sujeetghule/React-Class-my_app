import React, { Component } from 'react'
import PropsDes2 from './PropsDes2'

export default class PropsDes1 extends Component {
  render() {
    return (
      <div>
        <PropsDes2 obj = {{name:"ganesh",surname:"Gaytonde"}}>

        </PropsDes2>
      </div>
    )
  }
}
